package com.exemplo.loja_pedido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaPedidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaPedidoApplication.class, args);
	}

}
