package com.exemplo.loja_pedido.dto;

public class LaminaDTO {
    private String cor;
    private String padrao;

    // Getters e Setters
    
    public String getCor() {
        return cor;
    }
    public void setCor(String cor) {
        this.cor = cor;
    }
    public String getPadrao() {
        return padrao;
    }
    public void setPadrao(String padrao) {
        this.padrao = padrao;
    }

    
}
